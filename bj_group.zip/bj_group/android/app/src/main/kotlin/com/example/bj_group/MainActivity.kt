package com.example.bj_group

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
